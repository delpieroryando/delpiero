package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	users = map[string]string{
		"user1": "password123",
	}
	balances = map[string]float64{
		"user1": 100,
	}
	products = map[string]float64{
		"apple":  1.0,
		"banana": 0.5,
	}
	cart     = make(map[string]map[string]int)
	receipts = make(map[string]string)
	mu       = &sync.Mutex{}
)

func main() {
	http.HandleFunc("/login", loginHandler)
	http.HandleFunc("/", indexHandler)
	http.HandleFunc("/add_to_cart/", addToCartHandler)
	http.HandleFunc("/checkout", checkoutHandler)
	http.HandleFunc("/print_receipt", printReceiptHandler)
	http.HandleFunc("/delete_from_cart/", deleteFromCartHandler)
	http.HandleFunc("/logout", logoutHandler)
	http.ListenAndServe(":8080", nil)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		username := r.FormValue("username")
		password := r.FormValue("password")

		if storedPass, ok := users[username]; ok && storedPass == password {
			http.SetCookie(w, &http.Cookie{
				Name:  "session",
				Value: username,
			})
			http.Redirect(w, r, "/", http.StatusSeeOther)
			return
		}
		// Display invalid credential message
		data, err := ioutil.ReadFile("login.html")
		if err != nil {
			http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			return
		}
		content := string(data)
		content = strings.Replace(content, "{{.ErrorMessage}}", "Invalid credentials, please try again.", 1)
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte(content))
		return
	}

	data, err := ioutil.ReadFile("login.html")
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	content := string(data)
	content = strings.Replace(content, "{{.ErrorMessage}}", "", 1)
	w.Header().Set("Content-Type", "text/html")
	w.Write([]byte(content))
}

func indexHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	username := cookie.Value
	userCart, ok := cart[username]
	if !ok {
		userCart = make(map[string]int)
		cart[username] = userCart
	}

	// Get sorted list of product keys
	productKeys := make([]string, 0, len(products))
	for key := range products {
		productKeys = append(productKeys, key)
	}
	sort.Strings(productKeys)

	content := fmt.Sprintf("Hello, %s! Available products:<br>", username)
	for _, product := range productKeys {
		price := products[product]
		content += fmt.Sprintf(`
			%s: $%.2f 
			<form action="/add_to_cart/%s" method="POST" style="display:inline;">
				<input type="number" name="quantity" value="1" min="1">
				<input type="submit" value="Add to cart">
			</form>
			<form action="/delete_from_cart/%s" method="POST" style="display:inline;">
				<input type="hidden" name="delete_product" value="%s">
				<input type="submit" value="Delete">
			</form>
			<br>`, product, price, product, product, product)
	}

	content += "<br>Your cart:<br>"
	// Get sorted list of cart keys
	cartKeys := make([]string, 0, len(userCart))
	for key := range userCart {
		cartKeys = append(cartKeys, key)
	}
	sort.Strings(cartKeys)

	for _, product := range cartKeys {
		quantity := userCart[product]
		content += fmt.Sprintf("%s: %d ", product, quantity)
	}

	content += `<br><a href="/checkout">Checkout</a> | <a href="/logout">Logout</a>`
	fmt.Fprintf(w, template(content))
}

func addToCartHandler(w http.ResponseWriter, r *http.Request) {
	product := r.URL.Path[len("/add_to_cart/"):]
	cookie, err := r.Cookie("session")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	quantity, err := strconv.Atoi(r.FormValue("quantity"))
	if err != nil || quantity < 1 {
		quantity = 1
	}

	mu.Lock()
	defer mu.Unlock()

	username := cookie.Value
	userCart, ok := cart[username]
	if !ok {
		userCart = make(map[string]int)
		cart[username] = userCart
	}

	userCart[product] += quantity
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func checkoutHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	username := cookie.Value
	userCart, ok := cart[username]
	if !ok {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	total := 0.0
	receipt := fmt.Sprintf("Receipt for %s:<br><br>", username)
	// Get sorted list of cart keys
	cartKeys := make([]string, 0, len(userCart))
	for key := range userCart {
		cartKeys = append(cartKeys, key)
	}
	sort.Strings(cartKeys)

	for _, product := range cartKeys {
		quantity := userCart[product]
		price := products[product]
		total += price * float64(quantity)
		receipt += fmt.Sprintf("%s x %d = $%.2f<br>", product, quantity, price*float64(quantity))
	}

	balances[username] -= total
	cart[username] = make(map[string]int)

	receipt += fmt.Sprintf("<br>Total: $%.2f<br>", total)
	receipt += `<br><a href="/">Back to Home</a> | <a href="/print_receipt">Print Receipt</a> | <a href="/logout">Logout</a>`
	receipts[username] = receipt // Save the receipt for printing

	fmt.Fprintf(w, template(receipt))
}

func printReceiptHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	username := cookie.Value

	mu.Lock()
	defer mu.Unlock()

	receipt, ok := receipts[username]
	if !ok {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	// Parse the receipt to get the items and totals
	items := ""
	subtotal := 0.0
	lines := strings.Split(receipt, "<br>")
	for _, line := range lines {
		if strings.Contains(line, " x ") {
			item := line[:strings.Index(line, " x ")]
			qtyStr := line[strings.Index(line, " x ")+3 : strings.Index(line, " = $")]
			priceStr := line[strings.Index(line, " = $")+4:]
			qty, _ := strconv.Atoi(strings.TrimSpace(qtyStr))
			price, _ := strconv.ParseFloat(strings.TrimSpace(priceStr), 64)

			// Adjust price if qty > 9
			if qty > 9 {
				totalPriceStr := line[strings.LastIndex(line, "$")+1:]
				totalPrice, _ := strconv.ParseFloat(strings.TrimSpace(totalPriceStr), 64)
				price = totalPrice / float64(qty)
			}

			items += fmt.Sprintf("%-17s %-6s $%-7s $%.2f\n", item, qtyStr, priceStr, float64(qty)*price)
			subtotal += float64(qty) * price
		}
	}

	tax := subtotal * 0.05
	total := subtotal + tax

	// Generate current date and time
	currentTime := time.Now()
	date := currentTime.Format("2006-01-02")
	time := currentTime.Format("15:04:05")

	// Create the formatted receipt with correct tax percentage display
	formattedReceipt := fmt.Sprintf(`
---------------------------------------------------------
                  MY STORE
            123 Main Street, City
              Tel: (123) 456-7890
---------------------------------------------------------
Date: %s           Time: %s
---------------------------------------------------------
Item              Qty    Price    Total
---------------------------------------------------------
%s
---------------------------------------------------------
Subtotal:                          $%.2f
Tax		:                          $%.2f
---------------------------------------------------------
Total:                             $%.2f
---------------------------------------------------------
         Thank you for shopping with us!
---------------------------------------------------------
`, date, time, items, subtotal, tax, total)

	// Replace "(MISSING)" with "Tax (5%)"
	formattedReceipt = strings.ReplaceAll(formattedReceipt, "(5%%)", "(5%)")

	fmt.Fprintf(w, printTemplate(formattedReceipt))
}

func deleteFromCartHandler(w http.ResponseWriter, r *http.Request) {
	product := r.URL.Path[len("/delete_from_cart/"):]
	cookie, err := r.Cookie("session")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	username := cookie.Value
	userCart, ok := cart[username]
	if !ok {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	delete(userCart, product)
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:   "session",
		Value:  "",
		MaxAge: -1, // Set MaxAge to -1 to delete the cookie
	})
	http.Redirect(w, r, "/login", http.StatusSeeOther)
}

func template(content string) string {
	return fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FlakyOrderApp</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #50b3a2;
            color: #fff;
            padding-top: 30px;
            min-height: 70px;
            border-bottom: #e8491d 3px solid;
        }
        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            font-size: 16px;
        }
        ul {
            padding: 0;
            list-style: none;
        }
        ul li {
            display: inline;
            padding: 0 20px 0 20px;
        }
        .button_1 {
            height: 38px;
            background: #e8491d;
            border: none;
            padding-left: 20px;
            padding-right: 20px;
            color: #fff;
        }
        .main {
            padding: 20px;
            background: #fff;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>FlakyOrderApp</h1>
        </div>
    </header>
    <div class="container">
        <div class="main">
            %s
        </div>
    </div>
</body>
</html>`, content)
}

func printTemplate(content string) string {
	return fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        body {
            font-family: Courier, monospace;
            margin: 0;
            padding: 0;
            background-color: #fff;
        }
        .receipt {
            width: 80%%;
            margin: auto;
            padding: 20px;
            border: 1px solid #000;
        }
        .receipt pre {
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .buttons {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="receipt">
        <pre>
%s
        </pre>
        <div class="buttons">
            <button onclick="window.print()">Print</button>
            <button onclick="window.location.href='/'">Back to Home</button>
        </div>
    </div>
</body>
</html>`, content)
}
